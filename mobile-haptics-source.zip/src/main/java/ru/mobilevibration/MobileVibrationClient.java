package ru.mobilevibration;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public final class MobileVibrationClient implements ClientModInitializer {
    public static final String MOD_ID = "mobile-vibration";

    private static final KeyMapping.Category CATEGORY =
            KeyMapping.Category.register(
                    Identifier.fromNamespaceAndPath(MOD_ID, "settings")
            );

    private static final KeyMapping SETTINGS_KEY =
            KeyBindingHelper.registerKeyBinding(
                    new KeyMapping(
                            "key.mobile_vibration.settings",
                            InputConstants.Type.KEYSYM,
                            GLFW.GLFW_KEY_H,
                            CATEGORY
                    )
            );

    private int retryTicks;

    @Override
    public void onInitializeClient() {
        HapticManager.initialize();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!NativeVibrator.isAvailable()) {
                retryTicks++;
                if (retryTicks >= 40) {
                    retryTicks = 0;
                    NativeVibrator.init();
                }
            }

            while (SETTINGS_KEY.consumeClick()) {
                client.setScreen(new HapticsScreen(client.screen));
            }
        });

        ClientCommandRegistrationCallback.EVENT.register(
                (dispatcher, registryAccess) -> dispatcher.register(
                        ClientCommandManager.literal("mobilevibration")
                                .executes(context -> {
                                    Minecraft client = Minecraft.getInstance();
                                    client.setScreen(new HapticsScreen(client.screen));
                                    return 1;
                                })
                )
        );
    }
}
