package ru.mobilevibration.mixin;

import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.phys.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.mobilevibration.HapticManager;

@Mixin(MultiPlayerGameMode.class)
public final class ClientPlayerInteractionManagerMixin {
    @Unique
    private boolean mobileVibration$holdingBlockItem;

    @Inject(method = "destroyBlock", at = @At("RETURN"))
    private void mobileVibration$onBreak(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValue()) HapticManager.breakBlock();
    }

    @Inject(method = "useItemOn", at = @At("HEAD"))
    private void mobileVibration$rememberBlockItem(
            LocalPlayer player,
            InteractionHand hand,
            BlockHitResult hitResult,
            CallbackInfoReturnable<InteractionResult> cir) {
        mobileVibration$holdingBlockItem =
                player.getItemInHand(hand).getItem() instanceof BlockItem;
    }

    @Inject(method = "useItemOn", at = @At("RETURN"))
    private void mobileVibration$onPlace(
            LocalPlayer player,
            InteractionHand hand,
            BlockHitResult hitResult,
            CallbackInfoReturnable<InteractionResult> cir) {
        if (mobileVibration$holdingBlockItem && cir.getReturnValue().consumesAction()) {
            HapticManager.placeBlock();
        }
        mobileVibration$holdingBlockItem = false;
    }
}
