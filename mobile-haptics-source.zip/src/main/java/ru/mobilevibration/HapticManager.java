package ru.mobilevibration;

public final class HapticManager {
    private static final MobileVibrationConfig CONFIG = MobileVibrationConfig.load();

    private HapticManager() {}

    public static void initialize() {
        NativeVibrator.init();
    }

    public static MobileVibrationConfig getConfig() {
        return CONFIG;
    }

    public static void save() {
        CONFIG.save();
    }

    public static void breakBlock() {
        if (CONFIG.enabled && CONFIG.breakEnabled) {
            vibrate();
        }
    }

    public static void placeBlock() {
        if (CONFIG.enabled && CONFIG.placeEnabled) {
            vibrate();
        }
    }

    public static void test() {
        if (CONFIG.enabled) {
            vibrate();
        }
    }

    private static void vibrate() {
        try {
            NativeVibrator.vibrate(CONFIG.durationMs, CONFIG.strength);
        } catch (Throwable ignored) {
        }
    }
}
