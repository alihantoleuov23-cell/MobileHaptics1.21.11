package ru.mobilevibration;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class HapticsScreen extends Screen {
    private final Screen parent;
    private EditBox durationBox;
    private EditBox strengthBox;

    public HapticsScreen(Screen parent) {
        super(Component.translatable("screen.mobile_vibration.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        MobileVibrationConfig config = HapticManager.getConfig();

        this.addRenderableWidget(CycleButton.onOffBuilder(config.enabled)
                .create(centerX - 100, 35, 200, 20,
                        Component.translatable("option.mobile_vibration.enabled"),
                        (button, value) -> config.enabled = value));

        this.addRenderableWidget(CycleButton.onOffBuilder(config.breakEnabled)
                .create(centerX - 100, 58, 200, 20,
                        Component.translatable("option.mobile_vibration.break"),
                        (button, value) -> config.breakEnabled = value));

        this.addRenderableWidget(CycleButton.onOffBuilder(config.placeEnabled)
                .create(centerX - 100, 81, 200, 20,
                        Component.translatable("option.mobile_vibration.place"),
                        (button, value) -> config.placeEnabled = value));

        durationBox = createNumberBox(centerX - 75, 123, Integer.toString(config.durationMs));
        strengthBox = createNumberBox(centerX - 75, 161, Integer.toString(config.strength));

        this.addRenderableWidget(Button.builder(
                        Component.translatable("button.mobile_vibration.test"),
                        button -> HapticManager.test())
                .bounds(centerX - 150, 198, 300, 20)
                .build());

        this.addRenderableWidget(Button.builder(
                        Component.translatable("button.mobile_vibration.save"),
                        button -> saveAndClose())
                .bounds(centerX - 150, 224, 300, 20)
                .build());
    }

    private EditBox createNumberBox(int x, int y, String value) {
        EditBox box = new EditBox(this.font, x, y, 150, 20, Component.empty());
        box.setValue(value);
        box.setFilter(text -> text.matches("\\d{0,3}"));
        this.addRenderableWidget(box);
        return box;
    }

    private void saveAndClose() {
        MobileVibrationConfig config = HapticManager.getConfig();
        config.durationMs = clamp(parseInt(durationBox.getValue(), config.durationMs), 1, 500);
        config.strength = clamp(parseInt(strengthBox.getValue(), config.strength), 1, 100);
        HapticManager.save();
        this.minecraft.setScreen(parent);
    }

    private static int parseInt(String value, int fallback) {
        try { return Integer.parseInt(value); }
        catch (NumberFormatException ignored) { return fallback; }
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(value, max));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(0, 0, this.width, this.height, 0xFF101010);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, 15, 0xFFFFFF);
        graphics.drawString(this.font,
                Component.translatable("label.mobile_vibration.duration"),
                this.width / 2 - 75, 111, 0xFFFFFF);
        graphics.drawString(this.font,
                Component.translatable("label.mobile_vibration.strength"),
                this.width / 2 - 75, 149, 0xFFFFFF);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }
}
