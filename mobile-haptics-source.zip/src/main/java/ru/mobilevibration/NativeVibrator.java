package ru.mobilevibration;

import net.fabricmc.loader.api.FabricLoader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;

public final class NativeVibrator {
    public static final int INIT_SUCCESS = 0;
    public static final int INIT_GENERIC_ERROR = 1;
    public static final int INIT_DVM_NOT_FOUND = 2;
    public static final int INIT_VIBRATOR_NOT_FOUND = 3;

    private static final String LIBRARY_NAME = "mobilevibration";
    private static volatile boolean loaded;
    private static volatile boolean available;

    private NativeVibrator() {}

    public static synchronized void init() {
        if (available) return;
        try {
            if (!loaded) {
                loadLibrary();
                loaded = true;
            }
            int result = nativeInit();
            if (result == INIT_SUCCESS) {
                available = nativeIsAvailable();
                System.out.println("[Mobile Vibration] Native bridge ready, vibrator=" + available);
            } else {
                available = false;
                System.err.println("[Mobile Vibration] Native bridge init failed: 0x"
                        + Integer.toHexString(result).toUpperCase());
            }
        } catch (Throwable t) {
            available = false;
            System.err.println("[Mobile Vibration] Native initialization error:");
            t.printStackTrace();
        }
    }

    public static boolean isAvailable() {
        return available;
    }

    public static void vibrate(int durationMs, int strengthPercent) {
        if (!available) return;
        int duration = Math.max(1, Math.min(durationMs, 500));
        int strength = Math.max(1, Math.min(strengthPercent, 100));
        try {
            nativeVibrate(duration, strength);
        } catch (Throwable t) {
            System.err.println("[Mobile Vibration] Native vibration error:");
            t.printStackTrace();
        }
    }

    private static void loadLibrary() throws IOException {
        String arch = System.getProperty("os.arch", "").toLowerCase();
        String abi;
        if (arch.contains("aarch64") || arch.contains("arm64")) {
            abi = "arm64-v8a";
        } else if (arch.contains("x86_64") || arch.contains("amd64") || arch.contains("x86-64")) {
            abi = "x86_64";
        } else if (arch.equals("arm") || arch.contains("armv7") || arch.contains("armeabi")) {
            abi = "armeabi-v7a";
        } else if (arch.equals("x86")) {
            abi = "x86";
        } else {
            throw new IOException("Unsupported CPU architecture: " + arch);
        }

        String resource = "/native/" + abi + "/lib" + LIBRARY_NAME + ".so";
        Path directory = FabricLoader.getInstance().getConfigDir().resolve("mobile-vibration-native");
        Files.createDirectories(directory);
        Path output = directory.resolve("lib" + LIBRARY_NAME + ".so");

        try (InputStream input = NativeVibrator.class.getResourceAsStream(resource)) {
            if (input == null) {
                throw new IOException("Native library not found: " + resource);
            }
            try (OutputStream out = Files.newOutputStream(output)) {
                input.transferTo(out);
            }
        }

        System.load(output.toAbsolutePath().toString());
        System.out.println("[Mobile Vibration] Loaded native library: " + output);
    }

    private static native int nativeInit();
    private static native boolean nativeIsAvailable();
    private static native void nativeVibrate(int durationMs, int strengthPercent);
}
