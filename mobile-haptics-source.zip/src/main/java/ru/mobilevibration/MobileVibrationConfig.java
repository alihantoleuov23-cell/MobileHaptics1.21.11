package ru.mobilevibration;

import net.fabricmc.loader.api.FabricLoader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class MobileVibrationConfig {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir()
            .resolve("mobile-vibration.properties");

    public boolean enabled = true;
    public boolean breakEnabled = true;
    public boolean placeEnabled = true;
    public int durationMs = 30;
    public int strength = 70;

    public static MobileVibrationConfig load() {
        MobileVibrationConfig config = new MobileVibrationConfig();
        if (!Files.exists(FILE)) {
            config.save();
            return config;
        }

        Properties properties = new Properties();
        try (InputStream in = Files.newInputStream(FILE)) {
            properties.load(in);
            config.enabled = readBoolean(properties, "enabled", config.enabled);
            config.breakEnabled = readBoolean(properties, "breakEnabled", config.breakEnabled);
            config.placeEnabled = readBoolean(properties, "placeEnabled", config.placeEnabled);
            config.durationMs = readInt(properties, "durationMs", config.durationMs, 1, 500);
            config.strength = readInt(properties, "strength", config.strength, 1, 100);
        } catch (IOException ignored) {
        }
        return config;
    }

    public void save() {
        Properties properties = new Properties();
        properties.setProperty("enabled", Boolean.toString(enabled));
        properties.setProperty("breakEnabled", Boolean.toString(breakEnabled));
        properties.setProperty("placeEnabled", Boolean.toString(placeEnabled));
        properties.setProperty("durationMs", Integer.toString(durationMs));
        properties.setProperty("strength", Integer.toString(strength));

        try {
            Files.createDirectories(FILE.getParent());
            try (OutputStream out = Files.newOutputStream(FILE)) {
                properties.store(out, "Mobile Vibration settings");
            }
        } catch (IOException ignored) {
        }
    }

    private static boolean readBoolean(Properties p, String key, boolean fallback) {
        String value = p.getProperty(key);
        return value == null ? fallback : Boolean.parseBoolean(value);
    }

    private static int readInt(Properties p, String key, int fallback, int min, int max) {
        try {
            return Math.max(min, Math.min(max,
                    Integer.parseInt(p.getProperty(key, Integer.toString(fallback)))));
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }
}
