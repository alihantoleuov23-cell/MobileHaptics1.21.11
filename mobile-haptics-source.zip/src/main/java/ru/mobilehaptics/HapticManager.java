package ru.mobilehaptics;

public final class HapticManager {
    private static MobileHapticsConfig config;
    private static boolean nativeReady;

    private HapticManager() {
    }

    public static void initialize() {
        config = MobileHapticsConfig.load();
        nativeReady = NativeVibrator.initialize();
    }

    public static MobileHapticsConfig config() {
        return config;
    }

    public static boolean isNativeReady() {
        return nativeReady;
    }

    public static void vibrateBreak() {
        if (nativeReady && config.enabled && config.breakEnabled) {
            NativeVibrator.vibrate(config.breakDuration, config.breakAmplitude);
        }
    }

    public static void vibratePlace() {
        if (nativeReady && config.enabled && config.placeEnabled) {
            NativeVibrator.vibrate(config.placeDuration, config.placeAmplitude);
        }
    }

    public static void vibrateTest() {
        if (nativeReady && config.enabled) {
            NativeVibrator.vibrate(45, 210);
        }
    }
}
