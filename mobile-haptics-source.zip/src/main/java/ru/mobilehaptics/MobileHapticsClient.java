package ru.mobilehaptics;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class MobileHapticsClient implements ClientModInitializer {
    private static KeyBinding settingsKey;

    @Override
    public void onInitializeClient() {
        HapticManager.initialize();

        settingsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.mobile_haptics.settings",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_H,
                "category.mobile_haptics"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (settingsKey.wasPressed()) {
                client.setScreen(new HapticsScreen(client.currentScreen));
            }
        });
    }

    public static MinecraftClient client() {
        return MinecraftClient.getInstance();
    }
}
