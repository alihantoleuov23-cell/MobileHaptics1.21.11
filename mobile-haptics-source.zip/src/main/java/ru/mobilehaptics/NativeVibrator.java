package ru.mobilehaptics;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public final class NativeVibrator {
    private static boolean initialized;

    private NativeVibrator() {
    }

    public static synchronized boolean initialize() {
        if (initialized) {
            return true;
        }

        try {
            String arch = System.getProperty("os.arch", "").toLowerCase();
            String resource;

            if (arch.contains("aarch64") || arch.contains("arm64")) {
                resource = "/native/arm64-v8a/libmobilehaptics.so";
            } else if (arch.contains("x86_64") || arch.contains("amd64")) {
                resource = "/native/x86_64/libmobilehaptics.so";
            } else {
                return false;
            }

            Path dir = FabricLoader.getInstance().getConfigDir().resolve("mobile-haptics-native");
            Files.createDirectories(dir);
            Path library = dir.resolve("libmobilehaptics.so");

            try (InputStream in = NativeVibrator.class.getResourceAsStream(resource)) {
                if (in == null) {
                    return false;
                }
                Files.copy(in, library, StandardCopyOption.REPLACE_EXISTING);
            }

            System.load(library.toAbsolutePath().toString());
            initialized = nativeInit();
            return initialized;
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static void vibrate(long durationMs, int amplitude) {
        if (!initialized) {
            return;
        }
        try {
            nativeVibrate(durationMs, amplitude);
        } catch (Throwable ignored) {
        }
    }

    private static native boolean nativeInit();

    private static native void nativeVibrate(long durationMs, int amplitude);
}
