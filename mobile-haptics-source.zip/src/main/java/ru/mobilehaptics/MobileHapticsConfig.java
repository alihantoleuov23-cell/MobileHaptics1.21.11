package ru.mobilehaptics;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class MobileHapticsConfig {
    private static final Path FILE = FabricLoader.getInstance()
            .getConfigDir()
            .resolve("mobile-haptics.properties");

    public boolean enabled = true;
    public boolean breakEnabled = true;
    public boolean placeEnabled = true;
    public int breakDuration = 35;
    public int placeDuration = 20;
    public int breakAmplitude = 180;
    public int placeAmplitude = 120;

    public static MobileHapticsConfig load() {
        MobileHapticsConfig config = new MobileHapticsConfig();
        if (!Files.exists(FILE)) {
            config.save();
            return config;
        }

        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(FILE)) {
            p.load(in);
            config.enabled = bool(p, "enabled", config.enabled);
            config.breakEnabled = bool(p, "breakEnabled", config.breakEnabled);
            config.placeEnabled = bool(p, "placeEnabled", config.placeEnabled);
            config.breakDuration = integer(p, "breakDuration", config.breakDuration, 5, 200);
            config.placeDuration = integer(p, "placeDuration", config.placeDuration, 5, 200);
            config.breakAmplitude = integer(p, "breakAmplitude", config.breakAmplitude, 1, 255);
            config.placeAmplitude = integer(p, "placeAmplitude", config.placeAmplitude, 1, 255);
        } catch (IOException ignored) {
        }
        return config;
    }

    public void save() {
        Properties p = new Properties();
        p.setProperty("enabled", Boolean.toString(enabled));
        p.setProperty("breakEnabled", Boolean.toString(breakEnabled));
        p.setProperty("placeEnabled", Boolean.toString(placeEnabled));
        p.setProperty("breakDuration", Integer.toString(breakDuration));
        p.setProperty("placeDuration", Integer.toString(placeDuration));
        p.setProperty("breakAmplitude", Integer.toString(breakAmplitude));
        p.setProperty("placeAmplitude", Integer.toString(placeAmplitude));

        try {
            Files.createDirectories(FILE.getParent());
            try (OutputStream out = Files.newOutputStream(FILE)) {
                p.store(out, "Mobile Haptics settings");
            }
        } catch (IOException ignored) {
        }
    }

    private static boolean bool(Properties p, String key, boolean fallback) {
        String value = p.getProperty(key);
        return value == null ? fallback : Boolean.parseBoolean(value);
    }

    private static int integer(Properties p, String key, int fallback, int min, int max) {
        try {
            int value = Integer.parseInt(p.getProperty(key, Integer.toString(fallback)));
            return Math.max(min, Math.min(max, value));
        } catch (NumberFormatException e) {
            return fallback;
        }
    }
}
