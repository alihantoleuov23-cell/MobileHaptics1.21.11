package ru.mobilehaptics;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class HapticsScreen extends Screen {
    private final Screen parent;

    public HapticsScreen(Screen parent) {
        super(Text.literal("Mobile Haptics"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        MobileHapticsConfig c = HapticManager.config();
        int y = 70;

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Вибрация: " + (c.enabled ? "ВКЛ" : "ВЫКЛ")),
                b -> {
                    c.enabled = !c.enabled;
                    c.save();
                    rebuild();
                }).dimensions(this.width / 2 - 100, y, 200, 20).build());

        y += 26;
        addDrawableChild(ButtonWidget.builder(
                Text.literal("При разрушении: " + (c.breakEnabled ? "ВКЛ" : "ВЫКЛ")),
                b -> {
                    c.breakEnabled = !c.breakEnabled;
                    c.save();
                    rebuild();
                }).dimensions(this.width / 2 - 100, y, 200, 20).build());

        y += 26;
        addDrawableChild(ButtonWidget.builder(
                Text.literal("При установке: " + (c.placeEnabled ? "ВКЛ" : "ВЫКЛ")),
                b -> {
                    c.placeEnabled = !c.placeEnabled;
                    c.save();
                    rebuild();
                }).dimensions(this.width / 2 - 100, y, 200, 20).build());

        y += 26;
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Разрушение: " + c.breakDuration + " мс / " + c.breakAmplitude),
                b -> {
                    c.breakDuration = next(c.breakDuration, 10, 20, 35, 50, 75, 100);
                    c.save();
                    rebuild();
                }).dimensions(this.width / 2 - 100, y, 200, 20).build());

        y += 26;
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Установка: " + c.placeDuration + " мс / " + c.placeAmplitude),
                b -> {
                    c.placeDuration = next(c.placeDuration, 10, 20, 35, 50, 75, 100);
                    c.save();
                    rebuild();
                }).dimensions(this.width / 2 - 100, y, 200, 20).build());

        y += 26;
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Сила разрушения: " + c.breakAmplitude),
                b -> {
                    c.breakAmplitude = next(c.breakAmplitude, 50, 100, 140, 180, 220, 255);
                    c.save();
                    rebuild();
                }).dimensions(this.width / 2 - 100, y, 200, 20).build());

        y += 26;
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Сила установки: " + c.placeAmplitude),
                b -> {
                    c.placeAmplitude = next(c.placeAmplitude, 50, 80, 120, 160, 200, 255);
                    c.save();
                    rebuild();
                }).dimensions(this.width / 2 - 100, y, 200, 20).build());

        y += 28;
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Тест вибрации"),
                b -> HapticManager.vibrateTest()
        ).dimensions(this.width / 2 - 100, y, 200, 20).build());

        y += 26;
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Готово"),
                b -> this.client.setScreen(parent)
        ).dimensions(this.width / 2 - 100, y, 200, 20).build());
    }

    private void rebuild() {
        clearAndInit();
    }

    private static int next(int current, int... values) {
        for (int i = 0; i < values.length; i++) {
            if (values[i] == current) {
                return values[(i + 1) % values.length];
            }
        }
        return values[0];
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(
                this.textRenderer,
                Text.literal("Mobile Haptics"),
                this.width / 2,
                42,
                0xFFFFFF
        );
        context.drawCenteredTextWithShadow(
                this.textRenderer,
                Text.literal(HapticManager.isNativeReady() ? "Android bridge: OK" : "Android bridge: недоступен"),
                this.width / 2,
                55,
                HapticManager.isNativeReady() ? 0x55FF55 : 0xFF5555
        );
        super.render(context, mouseX, mouseY, delta);
    }
}
