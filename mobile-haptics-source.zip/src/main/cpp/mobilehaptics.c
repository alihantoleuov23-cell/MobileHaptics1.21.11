#include <jni.h>
#include <stdint.h>
#include <stdlib.h>

static JavaVM *g_vm = NULL;
static jobject g_application = NULL;
static jobject g_vibrator = NULL;
static jclass g_vibration_effect_class = NULL;
static jmethodID g_get_system_service = NULL;
static jmethodID g_create_one_shot = NULL;
static jmethodID g_vibrate = NULL;

static uintptr_t parse_pointer(const char *value) {
    if (value == NULL || *value == '\0') {
        return (uintptr_t)0;
    }
    return (uintptr_t)strtoull(value, NULL, 0);
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    (void)reserved;
    g_vm = vm;
    return JNI_VERSION_1_6;
}

JNIEXPORT jboolean JNICALL
Java_ru_mobilehaptics_NativeVibrator_nativeInit(JNIEnv *env, jclass cls) {
    (void)cls;

    const char *vm_text = getenv("DALVIK_JAVAVM");
    const char *app_text = getenv("DALVIK_APPLICATION");
    JavaVM *env_vm = (JavaVM *)parse_pointer(vm_text);
    jobject application_ref = (jobject)parse_pointer(app_text);

    if (env_vm != NULL) {
        g_vm = env_vm;
    }
    if (g_vm == NULL || application_ref == NULL) {
        return JNI_FALSE;
    }

    g_application = (*env)->NewGlobalRef(env, application_ref);
    if (g_application == NULL) {
        return JNI_FALSE;
    }

    jclass app_class = (*env)->GetObjectClass(env, g_application);
    if (app_class == NULL) {
        return JNI_FALSE;
    }

    g_get_system_service = (*env)->GetMethodID(
        env, app_class, "getSystemService",
        "(Ljava/lang/String;)Ljava/lang/Object;"
    );
    if (g_get_system_service == NULL) {
        return JNI_FALSE;
    }

    jstring name = (*env)->NewStringUTF(env, "vibrator");
    if (name == NULL) {
        return JNI_FALSE;
    }

    jobject vibrator = (*env)->CallObjectMethod(
        env, g_application, g_get_system_service, name
    );
    (*env)->DeleteLocalRef(env, name);

    if ((*env)->ExceptionCheck(env)) {
        (*env)->ExceptionClear(env);
        return JNI_FALSE;
    }
    if (vibrator == NULL) {
        return JNI_FALSE;
    }

    g_vibrator = (*env)->NewGlobalRef(env, vibrator);
    (*env)->DeleteLocalRef(env, vibrator);
    if (g_vibrator == NULL) {
        return JNI_FALSE;
    }

    jclass effect_local = (*env)->FindClass(env, "android/os/VibrationEffect");
    if (effect_local == NULL) {
        (*env)->ExceptionClear(env);
        return JNI_FALSE;
    }

    g_vibration_effect_class = (jclass)(*env)->NewGlobalRef(env, effect_local);
    (*env)->DeleteLocalRef(env, effect_local);

    if (g_vibration_effect_class == NULL) {
        return JNI_FALSE;
    }

    g_create_one_shot = (*env)->GetStaticMethodID(
        env, g_vibration_effect_class, "createOneShot",
        "(JI)Landroid/os/VibrationEffect;"
    );

    jclass vibrator_local = (*env)->GetObjectClass(env, g_vibrator);
    if (g_create_one_shot == NULL || vibrator_local == NULL) {
        return JNI_FALSE;
    }

    g_vibrate = (*env)->GetMethodID(
        env, vibrator_local, "vibrate",
        "(Landroid/os/VibrationEffect;)V"
    );
    (*env)->DeleteLocalRef(env, vibrator_local);

    return g_vibrate != NULL ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_ru_mobilehaptics_NativeVibrator_nativeVibrate(
    JNIEnv *env, jclass cls, jlong duration_ms, jint amplitude
) {
    (void)cls;

    if (g_vm == NULL || g_vibrator == NULL ||
        g_vibration_effect_class == NULL || g_create_one_shot == NULL ||
        g_vibrate == NULL) {
        return;
    }

    JNIEnv *call_env = env;
    int attached = 0;

    if (call_env == NULL) {
        if ((*g_vm)->GetEnv(g_vm, (void **)&call_env, JNI_VERSION_1_6) != JNI_OK) {
            if ((*g_vm)->AttachCurrentThread(g_vm, &call_env, NULL) != JNI_OK) {
                return;
            }
            attached = 1;
        }
    }

    if (duration_ms < 1) duration_ms = 1;
    if (duration_ms > 1000) duration_ms = 1000;
    if (amplitude < 1) amplitude = 1;
    if (amplitude > 255) amplitude = 255;

    jobject effect = (*call_env)->CallStaticObjectMethod(
        call_env, g_vibration_effect_class, g_create_one_shot,
        duration_ms, amplitude
    );

    if (!(*call_env)->ExceptionCheck(call_env) && effect != NULL) {
        (*call_env)->CallVoidMethod(
            call_env, g_vibrator, g_vibrate, effect
        );
    }

    if ((*call_env)->ExceptionCheck(call_env)) {
        (*call_env)->ExceptionClear(call_env);
    }

    if (effect != NULL) {
        (*call_env)->DeleteLocalRef(call_env, effect);
    }

    if (attached) {
        (*g_vm)->DetachCurrentThread(g_vm);
    }
}
