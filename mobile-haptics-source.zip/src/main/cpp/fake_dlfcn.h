#ifndef MOBILEVIBRATION_FAKE_DLFCN_H
#define MOBILEVIBRATION_FAKE_DLFCN_H
void *mobile_fake_dlopen(const char *libpath, int flags);
void *mobile_fake_dlsym(void *handle, const char *name);
int mobile_fake_dlclose(void *handle);
#endif
