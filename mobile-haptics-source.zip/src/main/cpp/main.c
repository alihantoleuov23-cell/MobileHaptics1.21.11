#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <stdbool.h>
#include "fake_dlfcn.h"

#define TAG "MobileVibration"
#define INIT_SUCCESS 0
#define INIT_GENERIC_ERROR 1
#define INIT_DVM_NOT_FOUND 2
#define INIT_VIBRATOR_NOT_FOUND 3

typedef jint (*jni_getvms_t)(JavaVM **, jsize, jsize *);

static JavaVM *g_minecraft_vm;
static JavaVM *g_android_vm;
static jobject g_vibrator;
static jclass g_vibrator_class;
static jclass g_vibration_effect_class;
static jmethodID g_vibrator_vibrate_effect;
static jmethodID g_vibrator_vibrate_legacy;
static jmethodID g_vibration_effect_create_one_shot;
static bool g_available;

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static bool clear_exception(JNIEnv *env, const char *where) {
    if (!(*env)->ExceptionCheck(env)) return false;
    LOGE("Java exception at %s", where);
    (*env)->ExceptionDescribe(env);
    (*env)->ExceptionClear(env);
    return true;
}

static jni_getvms_t get_jni_get_created_java_vms(void) {
    void *library = dlopen("libnativehelper.so", RTLD_LAZY);
    if (library) {
        void *symbol = dlsym(library, "JNI_GetCreatedJavaVMs");
        dlclose(library);
        if (symbol) return (jni_getvms_t) symbol;
    }

    library = mobile_fake_dlopen("libnativehelper.so", 0);
    if (!library) library = mobile_fake_dlopen("libart.so", 0);
    if (!library) return NULL;

    jni_getvms_t result = (jni_getvms_t)
            mobile_fake_dlsym(library, "JNI_GetCreatedJavaVMs");
    mobile_fake_dlclose(library);
    return result;
}

static JNIEnv *get_android_env(void) {
    if (!g_android_vm) return NULL;
    JNIEnv *env = NULL;
    jint result = (*g_android_vm)->GetEnv(g_android_vm, (void **) &env, JNI_VERSION_1_6);
    if (result == JNI_EDETACHED) {
        result = (*g_android_vm)->AttachCurrentThread(g_android_vm, &env, NULL);
    }
    if (result != JNI_OK) {
        LOGE("Could not attach current thread to Android VM");
        return NULL;
    }
    return env;
}

static jobject get_application(JNIEnv *env) {
    jclass activity_thread = (*env)->FindClass(env, "android/app/ActivityThread");
    if (!activity_thread) { clear_exception(env, "FindClass(ActivityThread)"); return NULL; }

    jmethodID current_activity_thread = (*env)->GetStaticMethodID(
            env, activity_thread, "currentActivityThread",
            "()Landroid/app/ActivityThread;");
    if (!current_activity_thread) {
        clear_exception(env, "GetStaticMethodID(currentActivityThread)");
        (*env)->DeleteLocalRef(env, activity_thread);
        return NULL;
    }

    jobject thread = (*env)->CallStaticObjectMethod(
            env, activity_thread, current_activity_thread);
    if (clear_exception(env, "currentActivityThread()") || !thread) {
        (*env)->DeleteLocalRef(env, activity_thread);
        return NULL;
    }

    jmethodID get_application = (*env)->GetMethodID(
            env, activity_thread, "getApplication",
            "()Landroid/app/Application;");
    if (!get_application) {
        clear_exception(env, "GetMethodID(getApplication)");
        (*env)->DeleteLocalRef(env, thread);
        (*env)->DeleteLocalRef(env, activity_thread);
        return NULL;
    }

    jobject application = (*env)->CallObjectMethod(env, thread, get_application);
    if (clear_exception(env, "getApplication()")) application = NULL;

    (*env)->DeleteLocalRef(env, thread);
    (*env)->DeleteLocalRef(env, activity_thread);
    return application;
}

static jobject create_vibrator(JNIEnv *env) {
    jobject application = get_application(env);
    if (!application) {
        LOGE("Could not get Android Application");
        return NULL;
    }

    jclass context_class = (*env)->FindClass(env, "android/content/Context");
    if (!context_class) {
        clear_exception(env, "FindClass(Context)");
        (*env)->DeleteLocalRef(env, application);
        return NULL;
    }

    jmethodID get_system_service = (*env)->GetMethodID(
            env, context_class, "getSystemService",
            "(Ljava/lang/String;)Ljava/lang/Object;");
    if (!get_system_service) {
        clear_exception(env, "GetMethodID(getSystemService)");
        (*env)->DeleteLocalRef(env, context_class);
        (*env)->DeleteLocalRef(env, application);
        return NULL;
    }

    jstring service_name = (*env)->NewStringUTF(env, "vibrator");
    jobject vibrator = (*env)->CallObjectMethod(
            env, application, get_system_service, service_name);
    bool failed = clear_exception(env, "getSystemService(vibrator)");

    (*env)->DeleteLocalRef(env, service_name);
    (*env)->DeleteLocalRef(env, context_class);
    (*env)->DeleteLocalRef(env, application);

    if (failed || !vibrator) {
        LOGE("Vibrator service unavailable");
        return NULL;
    }
    return vibrator;
}

static int init_android_vibrator(void) {
    JNIEnv *env = get_android_env();
    if (!env) return INIT_DVM_NOT_FOUND;

    jobject vibrator = create_vibrator(env);
    if (!vibrator) return INIT_VIBRATOR_NOT_FOUND;

    jclass vibrator_class = (*env)->FindClass(env, "android/os/Vibrator");
    if (!vibrator_class) {
        clear_exception(env, "FindClass(Vibrator)");
        (*env)->DeleteLocalRef(env, vibrator);
        return INIT_VIBRATOR_NOT_FOUND;
    }

    jclass effect_class = (*env)->FindClass(env, "android/os/VibrationEffect");
    if (!effect_class) {
        clear_exception(env, "FindClass(VibrationEffect)");
        (*env)->DeleteLocalRef(env, vibrator_class);
        (*env)->DeleteLocalRef(env, vibrator);
        return INIT_GENERIC_ERROR;
    }

    jmethodID create_one_shot = (*env)->GetStaticMethodID(
            env, effect_class, "createOneShot",
            "(JI)Landroid/os/VibrationEffect;");
    if (!create_one_shot) clear_exception(env, "GetStaticMethodID(createOneShot)");

    jmethodID vibrate_effect = (*env)->GetMethodID(
            env, vibrator_class, "vibrate",
            "(Landroid/os/VibrationEffect;)V");
    if (!vibrate_effect) clear_exception(env, "GetMethodID(vibrate(effect))");

    jmethodID vibrate_legacy = (*env)->GetMethodID(
            env, vibrator_class, "vibrate", "(J)V");
    if (!vibrate_legacy) clear_exception(env, "GetMethodID(vibrate(long))");

    if (!vibrate_effect && !vibrate_legacy) {
        LOGE("No usable Vibrator.vibrate method");
        (*env)->DeleteLocalRef(env, effect_class);
        (*env)->DeleteLocalRef(env, vibrator_class);
        (*env)->DeleteLocalRef(env, vibrator);
        return INIT_GENERIC_ERROR;
    }

    g_vibrator = (*env)->NewGlobalRef(env, vibrator);
    g_vibrator_class = (*env)->NewGlobalRef(env, vibrator_class);
    g_vibration_effect_class = (*env)->NewGlobalRef(env, effect_class);
    g_vibration_effect_create_one_shot = create_one_shot;
    g_vibrator_vibrate_effect = vibrate_effect;
    g_vibrator_vibrate_legacy = vibrate_legacy;

    (*env)->DeleteLocalRef(env, effect_class);
    (*env)->DeleteLocalRef(env, vibrator_class);
    (*env)->DeleteLocalRef(env, vibrator);

    if (!g_vibrator) return INIT_GENERIC_ERROR;
    g_available = true;
    LOGI("Android vibrator initialized successfully");
    return INIT_SUCCESS;
}

JNIEXPORT jint JNICALL Java_ru_mobilevibration_NativeVibrator_nativeInit(
        JNIEnv *env, jclass clazz) {
    (void) clazz;
    if (g_available) return INIT_SUCCESS;

    if ((*env)->GetJavaVM(env, &g_minecraft_vm) != JNI_OK) {
        LOGE("Could not get Minecraft Java VM");
        return INIT_GENERIC_ERROR;
    }

    jni_getvms_t get_vms = get_jni_get_created_java_vms();
    if (!get_vms) {
        LOGE("JNI_GetCreatedJavaVMs not found");
        return INIT_DVM_NOT_FOUND;
    }

    JavaVM *vms[8] = {0};
    jsize count = 0;
    jint result = get_vms(vms, 8, &count);
    if (result != JNI_OK || count <= 0) {
        LOGE("JNI_GetCreatedJavaVMs failed result=%d count=%d", result, (int) count);
        return INIT_DVM_NOT_FOUND;
    }

    g_android_vm = NULL;
    for (jsize i = 0; i < count; ++i) {
        if (vms[i] && vms[i] != g_minecraft_vm) {
            g_android_vm = vms[i];
            break;
        }
    }

    if (!g_android_vm) {
        LOGE("No separate Android VM was found");
        return INIT_DVM_NOT_FOUND;
    }

    return init_android_vibrator();
}

JNIEXPORT jboolean JNICALL Java_ru_mobilevibration_NativeVibrator_nativeIsAvailable(
        JNIEnv *env, jclass clazz) {
    (void) env; (void) clazz;
    return g_available ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL Java_ru_mobilevibration_NativeVibrator_nativeVibrate(
        JNIEnv *env, jclass clazz, jint duration_ms, jint strength_percent) {
    (void) env; (void) clazz;
    if (!g_available) return;

    JNIEnv *android_env = get_android_env();
    if (!android_env) return;

    jint duration = duration_ms < 1 ? 1 : (duration_ms > 500 ? 500 : duration_ms);
    jint strength = strength_percent < 1 ? 1 : (strength_percent > 100 ? 100 : strength_percent);
    jint amplitude = (strength * 255) / 100;
    if (amplitude < 1) amplitude = 1;
    if (amplitude > 255) amplitude = 255;

    if (g_vibration_effect_create_one_shot && g_vibrator_vibrate_effect) {
        jobject effect = (*android_env)->CallStaticObjectMethod(
                android_env, g_vibration_effect_class,
                g_vibration_effect_create_one_shot,
                (jlong) duration, amplitude);
        if (clear_exception(android_env, "VibrationEffect.createOneShot") || !effect) return;

        (*android_env)->CallVoidMethod(
                android_env, g_vibrator,
                g_vibrator_vibrate_effect, effect);
        clear_exception(android_env, "Vibrator.vibrate(VibrationEffect)");
        (*android_env)->DeleteLocalRef(android_env, effect);
        return;
    }

    if (g_vibrator_vibrate_legacy) {
        (*android_env)->CallVoidMethod(
                android_env, g_vibrator,
                g_vibrator_vibrate_legacy, (jlong) duration);
        clear_exception(android_env, "Vibrator.vibrate(long)");
    }
}
