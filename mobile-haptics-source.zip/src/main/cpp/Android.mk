LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := mobilevibration
LOCAL_SRC_FILES := main.c fake_dlfcn.c
LOCAL_CFLAGS := -Wall -Wextra -O2
LOCAL_LDLIBS := -llog -ldl
include $(BUILD_SHARED_LIBRARY)
