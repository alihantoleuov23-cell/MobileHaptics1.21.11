/* Adapted from DirectTouch's fake_dlfcn utility (LGPL-3.0).
 * https://github.com/RaydanOMGr/DirectTouch
 */
#include "fake_dlfcn.h"
#include <elf.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

#if defined(__arm__) || defined(__i386__)
#define MV_ELF_EHDR Elf32_Ehdr
#define MV_ELF_SHDR Elf32_Shdr
#define MV_ELF_SYM Elf32_Sym
#elif defined(__aarch64__) || defined(__x86_64__)
#define MV_ELF_EHDR Elf64_Ehdr
#define MV_ELF_SHDR Elf64_Shdr
#define MV_ELF_SYM Elf64_Sym
#else
#error "Unsupported Android architecture"
#endif

struct mobile_fake_ctx {
    void *load_addr;
    void *dynstr;
    void *dynsym;
    int nsyms;
    off_t bias;
};

int mobile_fake_dlclose(void *handle) {
    if (!handle) return 0;
    struct mobile_fake_ctx *ctx = (struct mobile_fake_ctx *) handle;
    free(ctx->dynsym);
    free(ctx->dynstr);
    free(ctx);
    return 0;
}

void *mobile_fake_dlopen(const char *libpath, int flags) {
    (void) flags;
    FILE *maps;
    char buff[1024];
    struct mobile_fake_ctx *ctx = NULL;
    off_t load_addr;
    off_t size;
    int fd = -1;
    int found = 0;
    void *shoff;
    MV_ELF_EHDR *elf = MAP_FAILED;

    maps = fopen("/proc/self/maps", "r");
    if (!maps) return NULL;
    while (!found && fgets(buff, sizeof(buff), maps)) {
        if (strstr(buff, libpath)) found = 1;
    }
    fclose(maps);
    if (!found) return NULL;
    if (sscanf(buff, "%lx", &load_addr) != 1) return NULL;

    if (libpath[0] != '/') {
        char *name_start = strstr(buff, libpath);
        if (name_start) {
            while (name_start > buff) {
                if (*name_start == ' ' && *(name_start + 1) == '/') {
                    libpath = name_start + 1;
                    break;
                }
                name_start--;
            }
            char *name_end = strchr(libpath, '\n');
            if (name_end) *name_end = '\0';
        }
    }

    fd = open(libpath, O_RDONLY);
    if (fd < 0) return NULL;
    size = lseek(fd, 0, SEEK_END);
    if (size <= 0) { close(fd); return NULL; }
    elf = (MV_ELF_EHDR *) mmap(NULL, size, PROT_READ, MAP_SHARED, fd, 0);
    close(fd);
    if (elf == MAP_FAILED) return NULL;

    ctx = (struct mobile_fake_ctx *) calloc(1, sizeof(*ctx));
    if (!ctx) { munmap(elf, size); return NULL; }
    ctx->load_addr = (void *) load_addr;
    shoff = ((void *) elf) + elf->e_shoff;

    for (int k = 0; k < elf->e_shnum; k++, shoff += elf->e_shentsize) {
        MV_ELF_SHDR *sh = (MV_ELF_SHDR *) shoff;
        switch (sh->sh_type) {
            case SHT_DYNSYM:
                if (ctx->dynsym) { mobile_fake_dlclose(ctx); munmap(elf, size); return NULL; }
                ctx->dynsym = malloc(sh->sh_size);
                if (!ctx->dynsym) { mobile_fake_dlclose(ctx); munmap(elf, size); return NULL; }
                memcpy(ctx->dynsym, ((void *) elf) + sh->sh_offset, sh->sh_size);
                ctx->nsyms = (int) (sh->sh_size / sizeof(MV_ELF_SYM));
                break;
            case SHT_STRTAB:
                if (ctx->dynstr) break;
                ctx->dynstr = malloc(sh->sh_size);
                if (!ctx->dynstr) { mobile_fake_dlclose(ctx); munmap(elf, size); return NULL; }
                memcpy(ctx->dynstr, ((void *) elf) + sh->sh_offset, sh->sh_size);
                break;
            case SHT_PROGBITS:
                if (!ctx->dynstr || !ctx->dynsym) break;
                ctx->bias = (off_t) sh->sh_addr - (off_t) sh->sh_offset;
                k = elf->e_shnum;
                break;
            default: break;
        }
    }
    munmap(elf, size);
    if (!ctx->dynstr || !ctx->dynsym) { mobile_fake_dlclose(ctx); return NULL; }
    return ctx;
}

void *mobile_fake_dlsym(void *handle, const char *name) {
    if (!handle || !name) return NULL;
    struct mobile_fake_ctx *ctx = (struct mobile_fake_ctx *) handle;
    MV_ELF_SYM *sym = (MV_ELF_SYM *) ctx->dynsym;
    char *strings = (char *) ctx->dynstr;
    for (int k = 0; k < ctx->nsyms; k++, sym++) {
        if (strcmp(strings + sym->st_name, name) == 0) {
            return ctx->load_addr + sym->st_value - ctx->bias;
        }
    }
    return NULL;
}
