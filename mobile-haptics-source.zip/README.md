# Mobile Vibration

Minecraft 1.21.11 Fabric mod for Android haptic feedback.

The native bridge is based on the JNI/Android VM approach used by DirectTouch 1.0.0.
DirectTouch is licensed under LGPL-3.0; this project keeps attribution in the native source.

Features: vibration toggle, break/place toggles, duration and strength settings, test button,
Mod Menu integration, H key, /mobilevibration command.
